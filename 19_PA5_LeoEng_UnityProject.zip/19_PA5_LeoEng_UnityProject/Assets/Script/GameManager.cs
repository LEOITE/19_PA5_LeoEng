﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager thismanager;

    private int Level = 1;
    private int coinRemain;

    public Text txt_coinRemain;

    // Start is called before the first frame update
    void Start()
    {
        thismanager = this;
        coinRemain = GameObject.FindGameObjectsWithTag("Coin").Length;
        txt_coinRemain.text = "Coin : " + coinRemain;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void coinUpdate()
    {

        coinRemain--;
        txt_coinRemain.text = "Coin : " + coinRemain;
        if (coinRemain <= 0)
        {
            int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
            if (SceneManager.sceneCountInBuildSettings > nextSceneIndex)
            {
                SceneManager.LoadScene(nextSceneIndex);
            }
            Debug.Log(nextSceneIndex);
        }
    }
    public void gamelose()
    {
        SceneManager.LoadScene("Lose");
    }
}
