﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRB;

    // Start is called before the first frame update
    void Start()
    {
        PlayerRB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void FixedUpdate()
    {
        float moveHor = Input.GetAxis("Horizontal");
        float moveVert = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHor, 0, moveVert);
        PlayerRB.AddForce(movement * speed * Time.deltaTime);
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Coin")
        {
            Destroy(other.gameObject);
            GameManager.thismanager.coinUpdate();

        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag == "Hazard")
        {
            GameManager.thismanager.gamelose();
        }
    }
}
